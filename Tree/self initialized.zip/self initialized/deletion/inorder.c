#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *left;
    struct node *right;
};
struct node *root=NULL;
struct node *createNode(int data)
{
    struct node *temp=(struct node*)malloc(sizeof(struct node));
    temp->data=data;
    temp->left=NULL;
    temp->right=NULL;
    return temp;
}
void inorder(struct node *root)
{
    if(root!=NULL)
    {
        inorder(root->left);
        printf("%d",root->data);
        inorder(root->right);
    }
}
struct node *insert(struct node *root,int data)
{
    if(root==NULL)
    {
        return createNode(data);
    }
    else if(data<root->data)
    {
        root->left=insert(root->left,data);
    }
    else if (data>root->data)
    {
        root->right=insert(root->right,data);
    }
    return root;
}
struct node *deleteNode(struct node *root,int toDel)
{
    //
    //base case jab ekk hi root ho
    //
    if(root==NULL)
    {
        return root;
    }
    //
    //agr root ka ekk child empty hoo
    //
    if(root->left==NULL)
    {
        struct node *temp=root->right;
        free(temp);
        return root;
    }
    else if (root->right==NULL)
    {
        struct node *temp=root->left;
        free(temp);
        return root;
    }
    //
    //if joh delete krna hai voh leaf ho
    //
    if(root->data>toDel)//agr root ka data bada ho toDel se to toDel toh left meh hua
    {
        root->left=deleteNode(root->left,toDel);
        return root;
    }
    else if(root->data<toDel)//agr toDel bada hua 
    {
        root->right=deleteNode(root->right,toDel);
        return root;
    }
    //
    //agr 2 childs ho
    //
    else
    {
        struct node *succParent=root;
        //successor find kro
        struct node *succ=root->right;
        while(succ->left!=NULL)
        {
            succParent=succ;
            succ=succ->left;
        }
        

        
    }






}
